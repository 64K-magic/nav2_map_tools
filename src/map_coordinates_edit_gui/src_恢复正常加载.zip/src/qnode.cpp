#include "map_coordinates_edit_gui/qnode.hpp"
#include <QDebug>

QNode::QNode(QObject* parent) : QObject(parent) {
    // create rclcpp node but do NOT call rclcpp::init here; assume main handles it
    node_ = std::make_shared<rclcpp::Node>("map_coordinates_edit_gui");
    exec_ = std::make_shared<rclcpp::executors::SingleThreadedExecutor>();
    exec_->add_node(node_);
    setup_subscriptions();
}

QNode::~QNode() {
    if (exec_) {
        exec_->cancel();
    }
    if (exec_thread_.joinable()) exec_thread_.join();
}

void QNode::start() {
    // run executor in background thread
    exec_thread_ = std::thread([this]() {
        exec_->spin();
    });
}

void QNode::setup_subscriptions() {
    using std::placeholders::_1;

    gps_sub_ = node_->create_subscription<sensor_msgs::msg::NavSatFix>(
        "/gps/fix", 10,
        [this](const sensor_msgs::msg::NavSatFix::SharedPtr msg) {
            emit gpsUpdated(msg->latitude, msg->longitude);
        }
    );

    prohibition_pub_ = node_->create_publisher<geometry_msgs::msg::PoseArray>(
        "prohibition_areas", 10
    );
}

void QNode::publishProhibitionAreas(const geometry_msgs::msg::PoseArray& areas) {
    prohibition_pub_->publish(areas);
}
 