#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QFileDialog>
#include <QComboBox>
#include <QLineEdit>
#include <QGroupBox>
#include <QRadioButton>
#include <QButtonGroup>
#include <QPainter>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QPixmap>
#include <QImage>
#include <QPointF>
#include <QPolygonF>
#include <QPen>
#include <QBrush>
#include <QColor>
#include <QMessageBox>
#include <QTimer>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QRegularExpression>
#include <QRandomGenerator>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/nav_sat_fix.hpp>
#include <geometry_msgs/msg/pose_array.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <memory>
#include <vector>
#include <cmath>
#include <algorithm>

#include "map_coordinates_edit_gui/qnode.hpp"

// Tile map loader class
class TileMapLoader : public QObject {
    Q_OBJECT

public:
    TileMapLoader(QObject* parent = nullptr) : QObject(parent), manager_(new QNetworkAccessManager(this)) {
        connect(manager_, &QNetworkAccessManager::finished, this, &TileMapLoader::onTileDownloaded);
    }

    void loadTileMap(const QString& baseUrl, int zoom, double centerLat, double centerLon, int tileSize = 256) {
        baseUrl_ = baseUrl;
        zoom_ = zoom;
        centerLat_ = centerLat;
        centerLon_ = centerLon;
        tileSize_ = tileSize;

        // Calculate tile coordinates for center
        int tileX = lon2tilex(centerLon_, zoom_);
        int tileY = lat2tiley(centerLat_, zoom_);

        // Load a 5x5 grid of tiles around center for better clarity
        tiles_.clear();
        pendingTiles_ = 0;

        for (int dx = -2; dx <= 2; ++dx) {
            for (int dy = -2; dy <= 2; ++dy) {
                int x = tileX + dx;
                int y = tileY + dy;
                // Work on a local copy so we don't mutate baseUrl_
                QString s = baseUrl_;
                s.replace("{level}", QString::number(zoom_));
                s.replace("{x}", QString::number(x));
                s.replace("{y}", QString::number(y));

                // For TianDiTu use a random subdomain t0..t7 if the URL contains t0
                if (s.contains("t0.")) {
                    QString subdomain = QString("t%1").arg(QRandomGenerator::global()->bounded(8));
                    s.replace("t0.", subdomain + ".");
                }

                // Normalize URL: remove accidental leading/trailing whitespace
                s = s.trimmed();
                // If scheme missing, try to add https
                QUrl q(s);
                if (!q.isValid() || q.scheme().isEmpty()) {
                    s = QString("https://") + s;
                    q = QUrl(s);
                }

                qDebug() << "Requesting URL:" << q.toString();
                QNetworkRequest request(q);
                QNetworkReply* reply = manager_->get(request);
                // remember which tile this reply corresponds to
                pendingReplies_[reply] = qMakePair(x, y);
                pendingTiles_++;
            }
        }
    }

    QPixmap getMapPixmap() const {
        if (tiles_.isEmpty()) return QPixmap();

        // Calculate bounds
        int minX = INT_MAX, minY = INT_MAX, maxX = INT_MIN, maxY = INT_MIN;
        for (auto it = tiles_.constBegin(); it != tiles_.constEnd(); ++it) {
            minX = std::min(minX, it.key().first);
            minY = std::min(minY, it.key().second);
            maxX = std::max(maxX, it.key().first);
            maxY = std::max(maxY, it.key().second);
        }

        int width = (maxX - minX + 1) * tileSize_;
        int height = (maxY - minY + 1) * tileSize_;

        QPixmap pixmap(width, height);
        pixmap.fill(Qt::transparent);
        QPainter painter(&pixmap);

        for (auto it = tiles_.constBegin(); it != tiles_.constEnd(); ++it) {
            int x = (it.key().first - minX) * tileSize_;
            int y = (it.key().second - minY) * tileSize_;
            painter.drawPixmap(x, y, it.value());
        }

        return pixmap;
    }

signals:
    void mapLoaded();

private slots:
    void onTileDownloaded(QNetworkReply* reply) {
        // find mapping for this reply
        QPair<int,int> coords = {INT_MIN, INT_MIN};
        if (pendingReplies_.contains(reply)) {
            coords = pendingReplies_.take(reply);
        }

        if (reply->error() == QNetworkReply::NoError) {
            QByteArray data = reply->readAll();
            QPixmap tile;
            if (tile.loadFromData(data)) {
                if (coords.first != INT_MIN) {
                    tiles_[coords] = tile;
                } else {
                    // Fallback: try to compute coords from URL path last components
                    QUrl u = reply->url();
                    QString path = u.path();
                    // attempt to parse /{level}/{x}/{y}.png
                    QRegularExpression re("/(\\d+)/(\\d+)/(\\d+)");
                    QRegularExpressionMatch m = re.match(path);
                    if (m.hasMatch()) {
                        int x = m.captured(2).toInt();
                        int y = m.captured(3).toInt();
                        tiles_[qMakePair(x,y)] = tile;
                    }
                }
            }
        } else {
            qDebug() << "Tile download error:" << reply->errorString();
        }

        pendingTiles_--;
        if (pendingTiles_ <= 0) {
            pendingTiles_ = 0;
            emit mapLoaded();
        }

        reply->deleteLater();
    }

private:
    int lon2tilex(double lon, int z) {
        return (int)(floor((lon + 180.0) / 360.0 * (1 << z)));
    }

    int lat2tiley(double lat, int z) {
        double latrad = lat * M_PI / 180.0;
        return (int)(floor((1.0 - asinh(tan(latrad)) / M_PI) / 2.0 * (1 << z)));
    }

    QNetworkAccessManager* manager_;
    QString baseUrl_;
    int zoom_;
    double centerLat_, centerLon_;
    int tileSize_;
    QMap<QPair<int, int>, QPixmap> tiles_;
    int pendingTiles_;
    QHash<QNetworkReply*, QPair<int,int>> pendingReplies_;
    bool firstTileLoad_ = true;
};

// Custom graphics item for drawing shapes
class ShapeItem : public QGraphicsItem {
public:
    enum ShapeType { Line, Rectangle, Circle, Polygon };

    ShapeItem(ShapeType type, const QPolygonF& points = QPolygonF())
        : type_(type), points_(points), finished_(false), radius_(0.0) {
        setFlag(QGraphicsItem::ItemIsSelectable);
    }

    void addPoint(const QPointF& point) {
        points_.append(point);
        if (type_ == Rectangle && points_.size() >= 2) finished_ = true;
        else if (type_ == Circle && points_.size() >= 1) {
            if (points_.size() == 1) center_ = point;
            else radius_ = QLineF(center_, point).length();
            if (points_.size() >= 2) finished_ = true;
        }
        else if (type_ == Polygon && points_.size() >= 3) finished_ = true;
        update();
    }

    void setRadius(double r) { radius_ = r; update(); }
    QPointF getCenter() const { return center_; }
    void finish() { finished_ = true; setFlag(QGraphicsItem::ItemIsMovable); update(); }

    bool isFinished() const { return finished_; }

    QRectF boundingRect() const override {
        if (type_ == Circle && finished_) {
            return QRectF(center_.x() - radius_, center_.y() - radius_, 2 * radius_, 2 * radius_).adjusted(-5, -5, 5, 5);
        }
        if (points_.isEmpty()) return QRectF();
        return points_.boundingRect().adjusted(-5, -5, 5, 5);
    }

    void paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*) override {
        painter->setPen(QPen(Qt::red, 2));
        painter->setBrush(QBrush(QColor(255, 0, 0, 50)));

        if (type_ == Line && points_.size() >= 2) {
            for (int i = 0; i < points_.size() - 1; ++i) {
                painter->drawLine(points_[i], points_[i+1]);
            }
        } else if (type_ == Rectangle && points_.size() >= 2) {
            QRectF rect(points_[0], points_[1]);
            painter->drawRect(rect);
        } else if (type_ == Circle && finished_) {
            painter->drawEllipse(center_, radius_, radius_);
        } else if (type_ == Polygon && points_.size() >= 3) {
            painter->drawPolygon(points_);
        }

        // Draw points
        painter->setPen(QPen(Qt::blue, 3));
        painter->setBrush(QBrush(Qt::blue));
        for (const QPointF& point : points_) {
            painter->drawEllipse(point, 3, 3);
        }
    }

private:
    ShapeType type_;
    QPolygonF points_;
    bool finished_;
    QPointF center_;
    double radius_;
};

class MapGraphicsView : public QGraphicsView {
    Q_OBJECT

public:
    MapGraphicsView(QGraphicsScene* scene, QWidget* parent = nullptr)
        : QGraphicsView(scene, parent), currentShape_(nullptr), drawingMode_(false), pressed_(false), panning_(false) {
        setMouseTracking(true);
        setRenderHint(QPainter::Antialiasing);
        setDragMode(QGraphicsView::NoDrag); // We'll handle panning manually
    }

    void setDrawingMode(bool enabled, ShapeItem::ShapeType type = ShapeItem::Line) {
        drawingMode_ = enabled;
        currentShapeType_ = type;
        if (!enabled && currentShape_) {
            currentShape_->finish();
            currentShape_ = nullptr;
        }
        // Drag mode is always NoDrag, we handle panning manually
    }

    void clearShapes() {
        QList<QGraphicsItem*> items = scene()->items();
        for (QGraphicsItem* item : items) {
            if (dynamic_cast<ShapeItem*>(item)) {
                scene()->removeItem(item);
                delete item;
            }
        }
        currentShape_ = nullptr;
    }

    std::vector<QRectF> getShapes() const {
        std::vector<QRectF> shapes;
        QList<QGraphicsItem*> items = scene()->items();
        for (QGraphicsItem* item : items) {
            ShapeItem* shape = dynamic_cast<ShapeItem*>(item);
            if (shape && shape->isFinished()) {
                shapes.push_back(shape->boundingRect());
            }
        }
        return shapes;
    }

signals:
    void shapeFinished();
    void zoomChanged(int newZoom);
    void centerChanged(double lat, double lon);

protected:
    void mousePressEvent(QMouseEvent* event) override {
        if (!drawingMode_ && event->button() == Qt::LeftButton) {
            // Start panning
            panning_ = true;
            lastPanPoint_ = event->pos();
            setCursor(Qt::ClosedHandCursor);
            event->accept();
            return;
        }

        if (drawingMode_) {
            QPointF scenePos = mapToScene(event->pos());
            if (event->button() == Qt::LeftButton) {
                pressed_ = true;
                if (currentShapeType_ == ShapeItem::Circle) {
                    if (!currentShape_) {
                        currentShape_ = new ShapeItem(ShapeItem::Circle);
                        scene()->addItem(currentShape_);
                        currentShape_->addPoint(scenePos); // set center
                    }
                } else {
                    if (!currentShape_) {
                        currentShape_ = new ShapeItem(currentShapeType_);
                        scene()->addItem(currentShape_);
                    }
                    currentShape_->addPoint(scenePos);
                    if (currentShape_->isFinished()) {
                        emit shapeFinished();
                        currentShape_ = nullptr;
                    }
                }
            } else if (event->button() == Qt::RightButton) {
                if (currentShape_ && currentShapeType_ == ShapeItem::Line) {
                    currentShape_->finish();
                    emit shapeFinished();
                    currentShape_ = nullptr;
                }
            }
        }
        QGraphicsView::mousePressEvent(event);
    }

    void mouseReleaseEvent(QMouseEvent* event) override {
        if (!drawingMode_ && event->button() == Qt::LeftButton && panning_) {
            // End panning
            panning_ = false;
            setCursor(Qt::ArrowCursor);
            event->accept();
            return;
        }

        if (drawingMode_ && event->button() == Qt::LeftButton) {
            pressed_ = false;
            if (currentShape_ && currentShapeType_ == ShapeItem::Circle) {
                currentShape_->finish();
                emit shapeFinished();
                currentShape_ = nullptr;
            }
        }
        QGraphicsView::mouseReleaseEvent(event);
    }

    void mouseMoveEvent(QMouseEvent* event) override {
        if (!drawingMode_ && panning_) {
            // Handle panning
            QPointF delta = event->pos() - lastPanPoint_;
            lastPanPoint_ = event->pos();
            // Pan the view
            QRectF viewRect = mapToScene(viewport()->rect()).boundingRect();
            viewRect.translate(-delta.x(), -delta.y());
            // Ensure we don't pan outside the scene
            QRectF sceneRect = scene()->sceneRect();
            if (viewRect.left() < sceneRect.left()) viewRect.moveLeft(sceneRect.left());
            if (viewRect.right() > sceneRect.right()) viewRect.moveRight(sceneRect.right());
            if (viewRect.top() < sceneRect.top()) viewRect.moveTop(sceneRect.top());
            if (viewRect.bottom() > sceneRect.bottom()) viewRect.moveBottom(sceneRect.bottom());
            // Set the new view rect
            fitInView(viewRect, Qt::KeepAspectRatioByExpanding);
            event->accept();
            return;
        }

        if (drawingMode_ && pressed_ && currentShape_ && currentShapeType_ == ShapeItem::Circle) {
            QPointF scenePos = mapToScene(event->pos());
            double radius = QLineF(currentShape_->getCenter(), scenePos).length();
            currentShape_->setRadius(radius);
        }
        QGraphicsView::mouseMoveEvent(event);
    }

    void keyPressEvent(QKeyEvent* event) override {
        if (event->key() == Qt::Key_Escape && currentShape_) {
            scene()->removeItem(currentShape_);
            delete currentShape_;
            currentShape_ = nullptr;
        }
        QGraphicsView::keyPressEvent(event);
    }

    void wheelEvent(QWheelEvent* event) override {
        // For tile map zoom, we change the zoom level instead of scaling the view
        if (event->angleDelta().y() > 0) {
            // Zoom in
            emit zoomChanged(1); // +1 zoom level
        } else {
            // Zoom out
            emit zoomChanged(-1); // -1 zoom level
        }
        event->accept();
    }

private:
    ShapeItem* currentShape_;
    bool drawingMode_;
    ShapeItem::ShapeType currentShapeType_;
    bool pressed_;
    bool panning_;
    QPoint lastPanPoint_;
};

class MainWindowWrapper : public QWidget {
    Q_OBJECT

public:
    MainWindowWrapper(QWidget *parent = nullptr) : QWidget(parent), qnode_(new QNode(this)), tileLoader_(new TileMapLoader(this)) {
        loadConfig();
        currentZoom_ = defaultZoom_;
        currentCenterLat_ = defaultCenterLat_;
        currentCenterLon_ = defaultCenterLon_;
        firstTileLoad_ = true;
        setupUI();
        setupConnections();
        qnode_->start();
        connect(tileLoader_, &TileMapLoader::mapLoaded, this, &MainWindowWrapper::onTileMapLoaded);
    }

    ~MainWindowWrapper() {
        delete qnode_;
        delete tileLoader_;
    }

    void loadConfig() {
        // Load default configuration from config/default_config.yaml
        QString configPath = QDir(QApplication::applicationDirPath()).absoluteFilePath("../config/default_config.yaml");
        QFile configFile(configPath);
        if (!configFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qWarning() << "Cannot open config file:" << configPath << "Using default values.";
            defaultCenterLat_ = 30.59170598225533;
            defaultCenterLon_ = 104.08352549614284;
            defaultZoom_ = 15;
            defaultTileUrl_ = "https://t0.tianditu.gov.cn/img_w/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=img&STYLE=default&TILEMATRIXSET=w&FORMAT=tiles&TILEMATRIX={level}&TILEROW={y}&TILECOL={x}&tk=3a4624a82f97a6f10db0da558390e530";
            return;
        }

        QTextStream in(&configFile);
        QString content = in.readAll();
        configFile.close();

        // Simple YAML parsing
        QStringList lines = content.split('\n');
        for (const QString& line : lines) {
            if (line.startsWith("default_center_lat:")) {
                defaultCenterLat_ = line.mid(19).trimmed().toDouble();
            } else if (line.startsWith("default_center_lon:")) {
                defaultCenterLon_ = line.mid(19).trimmed().toDouble();
            } else if (line.startsWith("default_zoom:")) {
                defaultZoom_ = line.mid(13).trimmed().toInt();
            } else if (line.startsWith("default_tile_url:")) {
                // start after the ':' character (17 characters)
                QString url = line.mid(17).trimmed();
                // remove surrounding quotes if present and trim again
                if (url.startsWith('"') && url.endsWith('"')) {
                    url = url.mid(1, url.length() - 2).trimmed();
                } else {
                    url.remove('"');
                    url = url.trimmed();
                }
                defaultTileUrl_ = url;
            }
        }

        qDebug() << "Config loaded successfully:" << QString::number(defaultCenterLat_, 'f', 14) << QString::number(defaultCenterLon_, 'f', 14) << defaultZoom_;
    }

public slots:
    void onGpsUpdate(double lat, double lon) {
        gpsLatEdit_->setText(QString::number(lat, 'f', 10));
        gpsLonEdit_->setText(QString::number(lon, 'f', 10));
    }

    void onShapeFinished() {
        updateProhibitionAreas();
    }

    void onZoomChanged(int delta) {
        currentZoom_ += delta;
        if (currentZoom_ < 1) currentZoom_ = 1;
        if (currentZoom_ > 20) currentZoom_ = 20; // Max zoom level
        loadOnlineTileMap();
    }

private slots:
    void loadMap() {
        if (mapTypeCombo_->currentText() == "Local PGM Map") {
            loadLocalPgmMap();
        } else if (mapTypeCombo_->currentText() == "Online Tile Map") {
            loadOnlineTileMap();
        }
    }

    void loadLocalPgmMap() {
        QString pgmFileName = QFileDialog::getOpenFileName(this, "Select PGM file", "", "PGM files (*.pgm)");
        if (pgmFileName.isEmpty()) return;

        // Try to find corresponding YAML file in the same directory
        QFileInfo pgmInfo(pgmFileName);
        QString yamlFileName = pgmInfo.absoluteDir().absoluteFilePath(pgmInfo.baseName() + ".yaml");
        if (!QFile::exists(yamlFileName)) {
            yamlFileName = pgmInfo.absoluteDir().absoluteFilePath(pgmInfo.baseName() + ".yml");
        }
        if (!QFile::exists(yamlFileName)) {
            // Try in the map folder
            QString mapDir = QDir(QApplication::applicationDirPath()).absoluteFilePath("../../src/map_coordinates_edit_gui/map");
            yamlFileName = QDir(mapDir).absoluteFilePath(pgmInfo.baseName() + ".yaml");
            if (!QFile::exists(yamlFileName)) {
                yamlFileName = QDir(mapDir).absoluteFilePath(pgmInfo.baseName() + ".yml");
            }
        }

        if (!QFile::exists(yamlFileName)) {
            QMessageBox::warning(this, "Error", "Cannot find corresponding YAML file for " + pgmFileName);
            return;
        }

        // Parse YAML file
        QFile yamlFile(yamlFileName);
        if (!yamlFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::warning(this, "Error", "Cannot open YAML file");
            return;
        }

        QTextStream in(&yamlFile);
        QString content = in.readAll();
        yamlFile.close();

        // Simple YAML parsing (basic implementation)
        double resolution = 0.0;
        double originX = 0.0, originY = 0.0;

        QStringList lines = content.split('\n');
        for (const QString& line : lines) {
            if (line.startsWith("resolution:")) {
                resolution = line.mid(11).trimmed().toDouble();
            } else if (line.startsWith("origin:")) {
                QString originStr = line.mid(7).trimmed();
                originStr.remove('[').remove(']');
                QStringList parts = originStr.split(',');
                if (parts.size() >= 2) {
                    originX = parts[0].trimmed().toDouble();
                    originY = parts[1].trimmed().toDouble();
                }
            }
        }

        // Load PGM image
        QPixmap pixmap(pgmFileName);
        if (!pixmap.isNull()) {
            mapItem_->setPixmap(pixmap);
            mapResolution_ = resolution;
            mapOriginX_ = originX;
            mapOriginY_ = originY;
            mapView_->fitInView(mapItem_, Qt::KeepAspectRatio);
            mapView_->centerOn(mapItem_);
        } else {
            QMessageBox::warning(this, "Error", "Cannot load PGM image: " + pgmFileName);
        }
    }

    void loadOnlineTileMap() {
        QString url = tileUrlEdit_->text();
        if (url.isEmpty()) {
            QMessageBox::warning(this, "Error", "Please enter a tile URL");
            return;
        }

        qDebug() << "Tile URL text box contents:" << url;
        url = url.trimmed();
        // remove surrounding quotes if present
        if (url.startsWith('"') && url.endsWith('"')) {
            url = url.mid(1, url.length() - 2);
        }

        // Use current center coordinates
        double centerLat = currentCenterLat_;
        double centerLon = currentCenterLon_;

        qDebug() << "Calling loadTileMap with zoom,center:" << currentZoom_ << centerLat << centerLon;
        tileLoader_->loadTileMap(url, currentZoom_, centerLat, centerLon);
    }

    void onTileMapLoaded() {
        QPixmap pixmap = tileLoader_->getMapPixmap();
        if (!pixmap.isNull()) {
            mapItem_->setPixmap(pixmap);
            mapItem_->setPos(0, 0);
            scene_->setSceneRect(0, 0, pixmap.width(), pixmap.height());
            mapView_->setSceneRect(scene_->sceneRect());
            // Disable scroll bars to allow panning within the view
            mapView_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            mapView_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            if (firstTileLoad_) {
                mapView_->resetTransform();
                mapView_->fitInView(mapItem_, Qt::KeepAspectRatio);
                mapView_->centerOn(mapItem_);
                firstTileLoad_ = false;
            } else {
                // keep current transform so tile-level zoom is effective; keep view centered
                mapView_->centerOn(mapItem_);
            }
        }
    }

    void startDrawing() {
        ShapeItem::ShapeType type = ShapeItem::Line;
        if (lineRadio_->isChecked()) type = ShapeItem::Line;
        else if (rectRadio_->isChecked()) type = ShapeItem::Rectangle;
        else if (circleRadio_->isChecked()) type = ShapeItem::Circle;
        else if (polygonRadio_->isChecked()) type = ShapeItem::Polygon;

        mapView_->setDrawingMode(true, type);
    }

    void zoomIn() {
        onZoomChanged(1);
    }

    void zoomOut() {
        onZoomChanged(-1);
    }

    void resetZoom() {
        currentZoom_ = defaultZoom_;
        loadOnlineTileMap();
    }

    void stopDrawing() {
        mapView_->setDrawingMode(false);
    }

    void clearShapes() {
        mapView_->clearShapes();
        updateProhibitionAreas();
    }

    void publishAreas() {
        if (prohibitionAreas_.poses.empty()) {
            QMessageBox::information(this, "No Areas", "No prohibition areas to publish.");
            return;
        }
        qnode_->publishProhibitionAreas(prohibitionAreas_);
        QMessageBox::information(this, "Published", "Prohibition areas published to topic.");
    }

    void calibrateGps() {
        // Simple calibration - in real implementation, would use more sophisticated methods
        QMessageBox::information(this, "GPS Calibration", "GPS calibration feature would be implemented here.");
    }

private:
    void setupUI() {
        QVBoxLayout* mainLayout = new QVBoxLayout(this);

        // Map view
        scene_ = new QGraphicsScene(this);
        mapItem_ = new QGraphicsPixmapItem();
        scene_->addItem(mapItem_);

        mapView_ = new MapGraphicsView(scene_, this);
        // hide scrollbars; panning is handled by drag mode
        mapView_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        mapView_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        mainLayout->addWidget(mapView_);

        // Control panel
        QHBoxLayout* controlLayout = new QHBoxLayout();

        // Map controls
        QGroupBox* mapGroup = new QGroupBox("Map");
        QVBoxLayout* mapLayout = new QVBoxLayout(mapGroup);

        // Map type selection
        QHBoxLayout* typeLayout = new QHBoxLayout();
        typeLayout->addWidget(new QLabel("Type:"));
        mapTypeCombo_ = new QComboBox();
        mapTypeCombo_->addItem("Local PGM Map");
        mapTypeCombo_->addItem("Online Tile Map");
        typeLayout->addWidget(mapTypeCombo_);
        mapLayout->addLayout(typeLayout);

        // URL input for tile map
        QHBoxLayout* urlLayout = new QHBoxLayout();
        urlLayout->addWidget(new QLabel("URL:"));
        tileUrlEdit_ = new QLineEdit(defaultTileUrl_);
        urlLayout->addWidget(tileUrlEdit_);
        mapLayout->addLayout(urlLayout);

        loadMapBtn_ = new QPushButton("Load Map");
        mapLayout->addWidget(loadMapBtn_);

        // Zoom controls
        QHBoxLayout* zoomLayout = new QHBoxLayout();
        zoomInBtn_ = new QPushButton("Zoom In");
        zoomOutBtn_ = new QPushButton("Zoom Out");
        resetZoomBtn_ = new QPushButton("Reset Zoom");
        zoomLayout->addWidget(zoomInBtn_);
        zoomLayout->addWidget(zoomOutBtn_);
        zoomLayout->addWidget(resetZoomBtn_);
        mapLayout->addLayout(zoomLayout);

        controlLayout->addWidget(mapGroup);

        // Drawing tools
        QGroupBox* drawGroup = new QGroupBox("Drawing Tools");
        QVBoxLayout* drawLayout = new QVBoxLayout(drawGroup);

        QButtonGroup* shapeGroup = new QButtonGroup(this);
        lineRadio_ = new QRadioButton("Line");
        rectRadio_ = new QRadioButton("Rectangle");
        circleRadio_ = new QRadioButton("Circle");
        polygonRadio_ = new QRadioButton("Polygon");
        lineRadio_->setChecked(true);

        shapeGroup->addButton(lineRadio_);
        shapeGroup->addButton(rectRadio_);
        shapeGroup->addButton(circleRadio_);
        shapeGroup->addButton(polygonRadio_);

        drawLayout->addWidget(lineRadio_);
        drawLayout->addWidget(rectRadio_);
        drawLayout->addWidget(circleRadio_);
        drawLayout->addWidget(polygonRadio_);

        startDrawBtn_ = new QPushButton("Start Drawing");
        stopDrawBtn_ = new QPushButton("Stop Drawing");
        clearShapesBtn_ = new QPushButton("Clear Shapes");

        drawLayout->addWidget(startDrawBtn_);
        drawLayout->addWidget(stopDrawBtn_);
        drawLayout->addWidget(clearShapesBtn_);

        controlLayout->addWidget(drawGroup);

        // GPS controls
        QGroupBox* gpsGroup = new QGroupBox("GPS");
        QVBoxLayout* gpsLayout = new QVBoxLayout(gpsGroup);

        QHBoxLayout* latLayout = new QHBoxLayout();
        latLayout->addWidget(new QLabel("Lat:"));
        gpsLatEdit_ = new QLineEdit("0.0");
        latLayout->addWidget(gpsLatEdit_);
        gpsLayout->addLayout(latLayout);

        QHBoxLayout* lonLayout = new QHBoxLayout();
        lonLayout->addWidget(new QLabel("Lon:"));
        gpsLonEdit_ = new QLineEdit("0.0");
        lonLayout->addWidget(gpsLonEdit_);
        gpsLayout->addLayout(lonLayout);

        QPushButton* calibrateBtn = new QPushButton("Calibrate GPS");
        calibrateBtn_ = calibrateBtn;
        gpsLayout->addWidget(calibrateBtn_);

        controlLayout->addWidget(gpsGroup);

        // Publish controls
        QGroupBox* publishGroup = new QGroupBox("Publish");
        QVBoxLayout* publishLayout = new QVBoxLayout(publishGroup);
        publishBtn_ = new QPushButton("Publish Prohibition Areas");
        publishLayout->addWidget(publishBtn_);
        controlLayout->addWidget(publishGroup);

        controlLayout->addStretch();
        mainLayout->addLayout(controlLayout);
    }

    void setupConnections() {
        connect(loadMapBtn_, &QPushButton::clicked, this, &MainWindowWrapper::loadMap);
        connect(zoomInBtn_, &QPushButton::clicked, this, &MainWindowWrapper::zoomIn);
        connect(zoomOutBtn_, &QPushButton::clicked, this, &MainWindowWrapper::zoomOut);
        connect(resetZoomBtn_, &QPushButton::clicked, this, &MainWindowWrapper::resetZoom);
        connect(startDrawBtn_, &QPushButton::clicked, this, &MainWindowWrapper::startDrawing);
        connect(stopDrawBtn_, &QPushButton::clicked, this, &MainWindowWrapper::stopDrawing);
        connect(clearShapesBtn_, &QPushButton::clicked, this, &MainWindowWrapper::clearShapes);
        connect(publishBtn_, &QPushButton::clicked, this, &MainWindowWrapper::publishAreas);
        connect(calibrateBtn_, &QPushButton::clicked, this, &MainWindowWrapper::calibrateGps);

        connect(mapView_, &MapGraphicsView::shapeFinished, this, &MainWindowWrapper::onShapeFinished);
        connect(mapView_, &MapGraphicsView::zoomChanged, this, &MainWindowWrapper::onZoomChanged);
        connect(qnode_, &QNode::gpsUpdated, this, &MainWindowWrapper::onGpsUpdate);
    }

    void updateProhibitionAreas() {
        // Convert shapes to PoseArray
        prohibitionAreas_.poses.clear();
        auto shapes = mapView_->getShapes();

        for (const auto& rect : shapes) {
            // For each shape, add corner points as poses
            QPointF topLeft = rect.topLeft();
            QPointF topRight = rect.topRight();
            QPointF bottomLeft = rect.bottomLeft();
            QPointF bottomRight = rect.bottomRight();

            geometry_msgs::msg::Pose pose1, pose2, pose3, pose4;
            pose1.position.x = topLeft.x(); pose1.position.y = topLeft.y();
            pose2.position.x = topRight.x(); pose2.position.y = topRight.y();
            pose3.position.x = bottomLeft.x(); pose3.position.y = bottomLeft.y();
            pose4.position.x = bottomRight.x(); pose4.position.y = bottomRight.y();

            prohibitionAreas_.poses.push_back(pose1);
            prohibitionAreas_.poses.push_back(pose2);
            prohibitionAreas_.poses.push_back(pose3);
            prohibitionAreas_.poses.push_back(pose4);
        }
    }

    QGraphicsScene* scene_;
    QGraphicsPixmapItem* mapItem_;
    MapGraphicsView* mapView_;
    QLineEdit* gpsLatEdit_;
    QLineEdit* gpsLonEdit_;
    QRadioButton* lineRadio_;
    QRadioButton* rectRadio_;
    QRadioButton* circleRadio_;
    QRadioButton* polygonRadio_;
    QComboBox* mapTypeCombo_;
    QLineEdit* tileUrlEdit_;
    QPushButton* loadMapBtn_;
    QPushButton* zoomInBtn_;
    QPushButton* zoomOutBtn_;
    QPushButton* resetZoomBtn_;
    QPushButton* startDrawBtn_;
    QPushButton* stopDrawBtn_;
    QPushButton* clearShapesBtn_;
    QPushButton* publishBtn_;
    QPushButton* calibrateBtn_;
    TileMapLoader* tileLoader_;

    QNode* qnode_;
    geometry_msgs::msg::PoseArray prohibitionAreas_;

    // Default configuration values
    double defaultCenterLat_;
    double defaultCenterLon_;
    int defaultZoom_;
    QString defaultTileUrl_;

    // Current map state
    int currentZoom_;
    double currentCenterLat_;
    double currentCenterLon_;

    bool firstTileLoad_;

    // Map metadata
    double mapResolution_;
    double mapOriginX_, mapOriginY_;
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    QApplication app(argc, argv);

    MainWindowWrapper window;
    window.show();

    int result = app.exec();
    rclcpp::shutdown();
    return result;
}

#include "main.moc"
